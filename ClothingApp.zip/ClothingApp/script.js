// Масив товарів (24 штук)
const products = [
  { id: 1, name: "Чорна футболка", price: 250, description: "Зручна чорна футболка з бавовни.", image: "images/photo1.jpg" },
  { id: 2, name: "Сіра кофта", price: 450, description: "Тепла сіра кофта на холодну погоду.", image: "images/photo2.jpg" },
  { id: 3, name: "Біла сорочка", price: 600, description: "Стильна біла сорочка для офісу.", image: "images/photo3.jpg" },
  { id: 4, name: "Жіночі чорні джинси", price: 850, description: "Модні чорні джинси високої якості.", image: "images/photo4.jpg" },
  { id: 5, name: "Чоловіча синя куртка", price: 1200, description: "Легка синя куртка на весну.", image: "images/photo5.jpg" },
  { id: 6, name: "Червона сукня", price: 950, description: "Елегантна червона сукня на вечір.", image: "images/photo6.jpg" },
  { id: 7, name: "Жовта майка", price: 220, description: "Яскрава майка для літа.", image: "images/photo7.jpg" },
  { id: 8, name: "Зелені спортивні штани", price: 700, description: "Спортивні зелені штани.", image: "images/photo8.jpg" },
  { id: 9, name: "Помаранчевий светр", price: 540, description: "Теплий светр з м’якої тканини для жінки.", image: "images/photo9.jpg" },
  { id: 10, name: "Чоловіча біла майка", price: 200, description: "Класична біла майка.", image: "images/photo10.jpg" },
  { id: 11, name: "Чоловічі сині джинси", price: 800, description: "Зручні сині джинси.", image: "images/photo11.jpg" },
  { id: 12, name: "Чорний светр", price: 500, description: "Універсальний чорний светр.", image: "images/photo12.jpg"},
  { id: 13, name: "Рожева сукня", price: 1000, description: "Романтична рожева сукня для прогулянок.", image: "images/photo13.jpg" },
  { id: 14, name: "Сіра сорочка", price: 550, description: "Повсякденна сорочка на гудзиках.", image: "images/photo14.jpg" },
  { id: 15, name: "Фіолетовий худі для чоловіків", price: 750, description: "Тепле худі на флісі.", image: "images/photo15.jpg" },
  { id: 16, name: "Бежеві штани", price: 720, description: "Стильні штани з легкої тканини.", image: "images/photo16.jpg" },
  { id: 17, name: "Коралова футболка", price: 290, description: "Яскрава футболка на кожен день.", image: "images/photo17.jpg" },
  { id: 18, name: "Сині шорти", price: 400, description: "Зручні літні шорти.", image: "images/photo18.jpg" },
  { id: 19, name: "Темно-зелена кофта", price: 650, description: "Затишна кофта для прохолодних вечорів.", image: "images/photo19.jpg" },
  { id: 20, name: "Червоні спортивні штани для жінок", price: 780, description: "Спортивні штани для стильного образу.", image: "images/photo20.jpg" },
  { id: 21, name: "Жіноча джинсова куртка", price: 1100, description: "Модна джинсова куртка.", image: "images/photo21.jpg" },
  { id: 22, name: "Сукня в горошок", price: 980, description: "Легка літня сукня з принтом горошок.", image: "images/photo22.jpg" },
  { id: 23, name: "Чоловіча футболка з принтом", price: 270, description: "Повсякденна футболка з принтом.", image: "images/photo23.jpg" },
  { id: 24, name: "Штани жіночі для фітнесу", price: 620, description: "Еластичні штани для тренувань.", image: "images/photo24.jpg" }
];

// Елементи DOM
const navbarLinks = document.querySelectorAll('.navbar a');
const pages = document.querySelectorAll('.page');
const productList = document.getElementById('productList');
const searchInput = document.getElementById('searchInput');
const sortSelect = document.getElementById('sortSelect');
const modal = document.getElementById('modal');
const modalClose = document.getElementById('modalClose');
const modalImg = document.getElementById('modalImg');
const modalName = document.getElementById('modalName');
const modalDesc = document.getElementById('modalDesc');
const modalPrice = document.getElementById('modalPrice');

// Назви для кожної секції
const pageTitles = {
  home: 'Головна',
  catalog: 'Каталог',
  contacts: 'Контакти',
  login: 'Вхід / Реєстрація',
};

function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => {
    page.classList.remove('active');
  });

  const targetPage = document.getElementById(pageId);
  if (targetPage) {
    targetPage.classList.add('active');
    document.title = pageTitles[pageId] || 'Онлайн Каталог Одягу';
  }
}

document.querySelectorAll('[data-page]').forEach(btn => {
  btn.addEventListener('click', () => {
    const target = btn.getAttribute('data-page');
    showPage(target);
  });
});

// Перемикання сторінок
navbarLinks.forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    navbarLinks.forEach(l => l.classList.remove('active'));
    link.classList.add('active');
    const targetPage = link.getAttribute('data-page');
    pages.forEach(page => page.classList.toggle('active', page.id === targetPage));
  });
});

// Рендер товарів
function renderProducts(items) {
  productList.innerHTML = '';
  if (items.length === 0) {
    productList.innerHTML = '<p>Товари не знайдено.</p>';
    return;
  }
  items.forEach(product => {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.tabIndex = 0;
    card.innerHTML = `
      <img src="${product.image}" alt="${product.name}" />
      <div class="product-name">${product.name}</div>
      <div class="product-price">${product.price} грн</div>
    `;
    card.addEventListener('click', () => openModal(product));
    card.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') openModal(product);
    });
    productList.appendChild(card);
  });
}

// Модальне вікно
function openModal(product) {
  modalImg.src = product.image;
  modalName.textContent = product.name;
  modalDesc.textContent = product.description;
  modalPrice.textContent = `Ціна: ${product.price} грн`;
  modal.style.display = 'flex';
}
modalClose.onclick = () => modal.style.display = 'none';
window.onclick = e => { if (e.target === modal) modal.style.display = 'none'; };

// Пошук і сортування
function filterAndSort() {
  let filtered = [...products];
  const searchText = searchInput.value.toLowerCase();
  if (searchText) {
    filtered = filtered.filter(p => p.name.toLowerCase().includes(searchText));
  }
  const sortVal = sortSelect.value;
  if (sortVal === 'price-asc') filtered.sort((a, b) => a.price - b.price);
  if (sortVal === 'price-desc') filtered.sort((a, b) => b.price - a.price);
  renderProducts(filtered);
  localStorage.setItem('searchText', searchText);
  localStorage.setItem('sortVal', sortVal);
}
searchInput.addEventListener('input', filterAndSort);
sortSelect.addEventListener('change', filterAndSort);

// Повідомлення
function showNotification(msg, type) {
  const note = document.getElementById('notification');
  if (note) {
    note.textContent = msg;
    note.className = `notification ${type}`;
    note.style.display = 'block';
    setTimeout(() => { note.style.display = 'none'; }, 4000);
  }
}
function showError(msg) {
  showNotification(msg, 'error');
}
function showSuccess(msg) {
  showNotification(msg, 'success');
}

// Авторизація / реєстрація
const showLogin = document.getElementById('showLogin');
const showRegister = document.getElementById('showRegister');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');

showLogin?.addEventListener('click', () => {
  loginForm.style.display = 'block';
  registerForm.style.display = 'none';
});

showRegister?.addEventListener('click', () => {
  loginForm.style.display = 'none';
  registerForm.style.display = 'block';
});

// Валідація реєстрації
const firstNameInput = document.getElementById('firstName');
const lastNameInput = document.getElementById('lastName');
const emailInput = document.getElementById('regEmail');
const passInput = document.getElementById('regPassword');
const confirmInput = document.getElementById('confirmPassword');

function validateName(name) {
  return /^[A-Z][a-z]+(-[A-Z][a-z]+)?$/.test(name);
} 
function validateEmail(email) {
  const allowedDomains = [
    'gmail.com', 'outlook.com', 'hotmail.com',
    'yahoo.com', 'icloud.com', 'ukr.net',
    'meta.ua', 'bigmir.net'
  ];

  const match = email.match(/^[^@]+@([^@]+)$/);
  return match && allowedDomains.includes(match[1].toLowerCase());
}

function validateLoginEmail(email) {
  const allowedDomains = [
    'gmail.com', 'outlook.com', 'hotmail.com',
    'yahoo.com', 'icloud.com', 'ukr.net',
    'meta.ua', 'bigmir.net'
  ];

  const match = email.match(/^[a-zA-Z0-9._%+-]+@([^@]+)$/);
  return match && allowedDomains.includes(match[1].toLowerCase());
}

function validatePassword(password) {
  return (
    /^[A-Za-z0-9!@#$%^&*()_+=\-{}\[\]:;"'<>,.?/\\|~`]{8,}$/.test(password) &&
    /[a-z]/.test(password) &&
    /[A-Z]/.test(password) &&
    /[0-9]/.test(password) &&
    /[!@#$%^&*()_+=\-{}\[\]:;"'<>,.?/\\|~`]/.test(password)
  );
}

function showFieldError(input, message) {
const wrapper = input.closest('.password-wrapper');
  const errorEl = wrapper ? wrapper.querySelector('.field-error') : input.parentElement.querySelector('.field-error');

  if (errorEl) {
  errorEl.textContent = message;
  }
}

function clearFieldError(input) {
  const wrapper = input.closest('.password-wrapper');
  const errorEl = wrapper ? wrapper.querySelector('.field-error') : input.parentElement.querySelector('.field-error');

  if (errorEl) {
    errorEl.textContent = '';
  }
}

function addInputValidation(input, validateFn, messageFn) {
  input.addEventListener('input', () => {
    if (!validateFn(input.value.trim())) {
      input.style.borderColor = 'red';
      showFieldError(input, messageFn());
    } else {
      input.style.borderColor = 'green';
      clearFieldError(input);
    }
  });
}

addInputValidation(firstNameInput, validateName, () => 'Ім’я повинне бути латиною, з великої літери. Можна з дефісом');
addInputValidation(lastNameInput, validateName, () => 'Прізвище повинне бути латиною, з великої літери. Можна з дефісом');
addInputValidation(emailInput, validateEmail, () => 'Email повинен бути латиницею з допустимим доменом (gmail, outlook тощо)');
addInputValidation(passInput, validatePassword, () => 'Пароль ≥8 символів, лише латиниця, велика і мала літера, цифра, спец. символ');
addInputValidation(confirmInput, () => confirmInput.value === passInput.value, () => 'Паролі мають співпадати');
const loginEmailInput = document.querySelector('#loginForm input[type="email"]');
addInputValidation(loginEmailInput, validateLoginEmail, () => 'Email повинен бути латиницею з допустимим доменом (gmail, outlook тощо)');
const loginPassInput = document.querySelector('#loginForm input[type="password"]');
addInputValidation(loginPassInput, validatePassword, () =>
  'Пароль ≥8 символів, лише латиниця, велика і мала літера, цифра, спец. символ'
);

registerForm?.addEventListener('submit', (e) => {
  e.preventDefault();
  const firstName = firstNameInput.value.trim();
  const lastName = lastNameInput.value.trim();
  const email = emailInput.value.trim();
  const pass = passInput.value;
  const confirmPass = confirmInput.value;

  if (!validateName(firstName)) return showError('Неправильне ім’я');
  if (!validateName(lastName)) return showError('Неправильне прізвище');
  if (!validateEmail(email)) return showError('Email повинен містити символ @');
  if (!validatePassword(pass)) return showError('Пароль не відповідає вимогам');
  if (pass !== confirmPass) return showError('Паролі не співпадають');

  showSuccess('Реєстрація успішна!');
  registerForm.reset();
  [firstNameInput, lastNameInput, emailInput, passInput, confirmInput].forEach(i => {
    i.style.borderColor = '';
    clearFieldError(i);
  });

  document.querySelector('[data-page="home"]').click();
});

loginForm?.addEventListener('submit', (e) => {
  e.preventDefault();

  const email = loginEmailInput.value.trim();
  const password = loginPassInput.value;

  if (!validateLoginEmail(email)) {
    showError('Email повинен бути латиницею з популярним доменом');
    loginEmailInput.style.borderColor = 'red';
    return;
  }

  if (!validatePassword(password)) {
    showError('Пароль не відповідає вимогам');
    loginPassInput.style.borderColor = 'red';
    return;
  }

  showSuccess('Успішний вхід!');
  document.querySelector('[data-page="home"]').click();
});

// "Око" для показу/приховування пароля
function togglePasswordVisibility(inputId, toggleId) {
  const input = document.getElementById(inputId);
  const toggle = document.getElementById(toggleId);
  const icon = toggle.querySelector('img');
  toggle.addEventListener('click', () => {
    const isHidden = input.type === 'password';
    input.type = isHidden ? 'text' : 'password';
    if (icon) {
      icon.src = isHidden ? 'images/Logo_image/eye_close.png' : 'images/Logo_image/eye_open.png';
      icon.alt = isHidden ? 'Сховати пароль' : 'Показати пароль';
    }
  });
}
togglePasswordVisibility('regPassword', 'togglePass');
togglePasswordVisibility('confirmPassword', 'toggleConfirm');
togglePasswordVisibility('loginPassword', 'toggleLoginPass');

window.addEventListener('load', () => {
  searchInput.value = localStorage.getItem('searchText') || '';
  sortSelect.value = localStorage.getItem('sortVal') || '';
  filterAndSort();
});

const allAuthInputs = document.querySelectorAll('.auth-form input');
allAuthInputs.forEach(input => {
  input.style.boxSizing = 'border-box';
  input.style.width = '100%';
});

